#version 120
#define BLOHO_DIMENSION 1
#define BLOHO_TEXTURED
#define BLOHO_LIGHTMAP
#define BLOHO_SURFACE
#define BLOHO_BLOCK_ENTITY
#define BLOHO_ENTITY_TINT
#define BLOHO_FAMILY 2.0
#define BLOHO_FOGGED
#include "/program/gbuffer/geometry.vsh"
