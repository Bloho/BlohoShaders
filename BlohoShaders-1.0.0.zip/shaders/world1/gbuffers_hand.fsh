#version 120
#define BLOHO_DIMENSION 1
#define BLOHO_TEXTURED
#define BLOHO_LIGHTMAP
#define BLOHO_SURFACE
#define BLOHO_FAMILY 4.0
#define BLOHO_HAND
/* DRAWBUFFERS:0123 */
#include "/program/gbuffer/geometry.fsh"
