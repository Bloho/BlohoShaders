#version 120
#define BLOHO_DIMENSION 1
#define BLOHO_TEXTURED
#define BLOHO_FOGGED
#define BLOHO_ADDITIVE
#include "/program/gbuffer/geometry.vsh"
