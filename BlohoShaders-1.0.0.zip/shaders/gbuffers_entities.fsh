#version 120
#define BLOHO_DIMENSION 0
#define BLOHO_TEXTURED
#define BLOHO_LIGHTMAP
#define BLOHO_SURFACE
#define BLOHO_ENTITY
#define BLOHO_ENTITY_TINT
#define BLOHO_FAMILY 3.0
#define BLOHO_FOGGED
/* DRAWBUFFERS:0123 */
#include "/program/gbuffer/geometry.fsh"
