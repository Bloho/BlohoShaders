#version 120
#define BLOHO_DIMENSION 0
#define BLOHO_TEXTURED
#define BLOHO_LIGHTMAP
#define BLOHO_FOGGED
/* DRAWBUFFERS:0 */
#include "/program/gbuffer/geometry.fsh"
