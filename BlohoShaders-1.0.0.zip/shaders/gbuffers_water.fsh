#version 120
#define BLOHO_DIMENSION 0
#define BLOHO_TEXTURED
#define BLOHO_LIGHTMAP
#define BLOHO_SURFACE
#define BLOHO_TERRAIN
#define BLOHO_FAMILY 5.0
#define BLOHO_FOGGED
/* DRAWBUFFERS:0123 */
#include "/program/gbuffer/geometry.fsh"
