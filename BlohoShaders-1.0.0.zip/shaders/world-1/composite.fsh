#version 120
#define BLOHO_DIMENSION -1
/* DRAWBUFFERS:0 */
#include "/program/composite/baseline.fsh"
