#version 120
#define BLOHO_DIMENSION 0
#define BLOHO_TEXTURED
#define BLOHO_FOGGED
#define BLOHO_ADDITIVE
/* DRAWBUFFERS:0 */
#include "/program/gbuffer/geometry.fsh"
